package com.solder.corecountdev;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
