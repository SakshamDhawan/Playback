export default interface CanvasGridOptions {
	rowSpacing: number;
}
