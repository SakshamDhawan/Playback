export default interface Dimensions {
    width: number;
    height: number;
}
