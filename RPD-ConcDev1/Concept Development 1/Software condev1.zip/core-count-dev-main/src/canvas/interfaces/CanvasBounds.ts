import Dimensions from "./Dimensions";
import Position from "./Position";

export default interface CanvasBounds extends Position, Dimensions {

}
