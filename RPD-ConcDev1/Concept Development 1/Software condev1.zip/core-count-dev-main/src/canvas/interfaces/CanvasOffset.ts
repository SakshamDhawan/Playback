export default interface CanvasOffset {
	x?: number;
	y?: number;
	width?: number;
	height?: number;
}
