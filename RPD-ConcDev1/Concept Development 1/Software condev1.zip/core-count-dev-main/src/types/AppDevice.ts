import { BleDevice } from "@capacitor-community/bluetooth-le";

type AppDevice = {
	device: BleDevice;
}

export default AppDevice;
