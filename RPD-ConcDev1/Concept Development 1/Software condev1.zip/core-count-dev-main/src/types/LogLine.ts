type LogLine = {
	line: string;
	type: 'info' | 'error' | 'warning';
}

export default LogLine;
